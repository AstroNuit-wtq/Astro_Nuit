import SwiftUI

struct ContentView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        ZStack {
            // Main sky view
            SkyScreen()
            
            // Overlay UI
            VStack {
                TopBar()
                Spacer()
                BottomToolbar()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .background(Color.black)
        .ignoresSafeArea()
    }
}

// MARK: - Top Bar
struct TopBar: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        HStack {
            // Location
            HStack(spacing: 6) {
                Image(systemName: "location.fill")
                    .font(.system(size: 13, weight: .medium))
                Text("Текущее место")
                    .font(.system(size: 13, weight: .medium))
            }
            .foregroundStyle(.white.opacity(0.9))
            
            Spacer()
            
            // Time
            Text(appState.currentDate.formatted(date: .abbreviated, time: .shortened))
                .font(.system(size: 13, weight: .medium, design: .monospaced))
                .foregroundStyle(.white.opacity(0.9))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background {
            if appState.useGlassEffect {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(.ultraThinMaterial)
            } else {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.black.opacity(0.55))
            }
        }
    }
}
