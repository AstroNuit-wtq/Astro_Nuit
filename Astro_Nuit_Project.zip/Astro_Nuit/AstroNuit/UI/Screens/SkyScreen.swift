import SwiftUI
import SceneKit

struct SkyScreen: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        ZStack {
            // Temporary gradient sky until full renderer is ready
            LinearGradient(
                colors: [
                    Color(red: 0.01, green: 0.02, blue: 0.08),
                    Color(red: 0.02, green: 0.04, blue: 0.12),
                    Color(red: 0.03, green: 0.05, blue: 0.15)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            // Placeholder for future SceneKit / Metal sky
            SceneView(
                scene: makePlaceholderScene(),
                options: [.allowsCameraControl, .autoenablesDefaultLighting]
            )
            .ignoresSafeArea()
            .opacity(0.9)
        }
    }
    
    private func makePlaceholderScene() -> SCNScene {
        let scene = SCNScene()
        scene.background.contents = UIColor.black
        
        // Simple star field placeholder
        for _ in 0..<800 {
            let sphere = SCNSphere(radius: CGFloat.random(in: 0.002...0.012))
            sphere.firstMaterial?.diffuse.contents = UIColor.white
            sphere.firstMaterial?.emission.contents = UIColor.white
            
            let node = SCNNode(geometry: sphere)
            let distance: Float = 8
            let theta = Float.random(in: 0...(2 * .pi))
            let phi = Float.random(in: 0...(.pi))
            
            node.position = SCNVector3(
                distance * sin(phi) * cos(theta),
                distance * cos(phi),
                distance * sin(phi) * sin(theta)
            )
            scene.rootNode.addChildNode(node)
        }
        
        return scene
    }
}
