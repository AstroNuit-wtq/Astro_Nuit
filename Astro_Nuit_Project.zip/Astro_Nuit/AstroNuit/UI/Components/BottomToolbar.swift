import SwiftUI

struct BottomToolbar: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        HStack(spacing: 18) {
            ToolbarButton(icon: "magnifyingglass", label: "Поиск")
            ToolbarButton(icon: "eye", label: "Сегодня")
            ToolbarButton(icon: "slider.horizontal.3", label: "Вид")
            
            // Night mode toggle
            Button {
                withAnimation(.easeInOut(duration: 0.25)) {
                    appState.isNightMode.toggle()
                }
            } label: {
                Image(systemName: appState.isNightMode ? "moon.fill" : "moon")
                    .font(.system(size: 20, weight: .medium))
                    .foregroundStyle(appState.isNightMode ? AppTheme.nightRed : .white)
                    .frame(width: 44, height: 44)
            }
            
            ToolbarButton(icon: appState.isSensorMode ? "location.north.line.fill" : "location.north.line", label: "AR")
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background {
            GlassPanel(cornerRadius: 22) {
                Color.clear
            }
        }
    }
}

struct ToolbarButton: View {
    let icon: String
    let label: String
    
    var body: some View {
        Button {
            // TODO: actions
        } label: {
            Image(systemName: icon)
                .font(.system(size: 20, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: 44, height: 44)
        }
    }
}
