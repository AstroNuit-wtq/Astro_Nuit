import SwiftUI

enum AppTheme {
    // Base dark palette
    static let background = Color(red: 0.02, green: 0.03, blue: 0.08)
    static let deepSpace = Color(red: 0.01, green: 0.02, blue: 0.06)
    
    // Accents
    static let starWhite = Color(red: 0.93, green: 0.95, blue: 1.0)
    static let accentBlue = Color(red: 0.45, green: 0.65, blue: 1.0)
    static let accentViolet = Color(red: 0.55, green: 0.45, blue: 0.95)
    
    // Night mode (red)
    static let nightRed = Color(red: 0.75, green: 0.12, blue: 0.08)
    static let nightRedDim = Color(red: 0.45, green: 0.08, blue: 0.05)
    
    // Glass
    static let glassOpacity: Double = 0.55
    
    static func textColor(nightMode: Bool) -> Color {
        nightMode ? nightRed : starWhite
    }
    
    static func accentColor(nightMode: Bool) -> Color {
        nightMode ? nightRed : accentBlue
    }
}
